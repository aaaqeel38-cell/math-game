# 🎮 Aqeel's Math Challenge — دليل النشر على App Store

هذي الحزمة تحوّل اللعبة (HTML) إلى تطبيق iOS حقيقي قابل للنشر على متجر آبل، باستخدام **Capacitor**.

---

## 📋 المتطلّبات قبل البدء

| المتطلّب | التفاصيل |
|---|---|
| 💻 جهاز **Mac** | إجباري — لتشغيل Xcode (لا يمكن من ويندوز) |
| 🛠️ **Xcode** | حمّله مجانًا من Mac App Store |
| 📦 **Node.js** | حمّله من [nodejs.org](https://nodejs.org) |
| 🍎 **حساب Apple Developer** | 99$ سنويًا — [developer.apple.com](https://developer.apple.com) |

---

## 🚀 الخطوات

### 1) جهّز المشروع
افتح **Terminal** داخل مجلّد `ios-app-package` ثم:

```bash
npm install
npx cap add ios
npx cap sync ios
```

> ملف اللعبة موجود جاهز في `www/index.html` — هذا هو محتوى التطبيق.

### 2) افتح المشروع في Xcode
```bash
npx cap open ios
```
راح يفتح Xcode تلقائيًا.

### 3) إعدادات داخل Xcode
1. اختر المشروع من الأعلى → تبويب **Signing & Capabilities**.
2. فعّل **Automatically manage signing**.
3. اختر **Team** (حساب Apple Developer حقّك).
4. غيّر **Bundle Identifier** لو تبي (حاليًا `com.aqeel.mathchallenge`).

### 4) جرّب على آيفونك
- وصّل الآيفون بالكمبيوتر، اختره من قائمة الأجهزة فوق، واضغط زر **▶ Run**.
- اللعبة راح تشتغل على جهازك مباشرة.

### 5) ارفعها على App Store
1. من Xcode: **Product → Archive**.
2. بعد ما يخلص، اضغط **Distribute App → App Store Connect**.
3. ادخل [App Store Connect](https://appstoreconnect.apple.com)، أنشئ التطبيق، أضف:
   - الاسم، الوصف، الفئة (**Education / Games**)
   - لقطات شاشة (Screenshots)
   - أيقونة التطبيق (1024×1024)
   - تصنيف العمر (مناسب 4+)
4. أرسله للمراجعة. عادة تاخذ آبل 1–3 أيام.

---

## 🎨 أيقونة التطبيق
تحتاج أيقونة **1024×1024 PNG**. تقدر تطلب مني أصمّمها لك بنفس ألوان اللعبة.
في Xcode: `App/App/Assets.xcassets/AppIcon` → اسحب الأيقونة هناك.

---

## ✏️ تعديل اللعبة لاحقًا
أي تعديل على اللعبة = استبدل `www/index.html` بالنسخة الجديدة، ثم:
```bash
npx cap sync ios
```

---

## ⚡ بديل أسرع (بدون App Store)
لو تبيها على جهازك فقط أو لمشاركتها برابط:
1. ارفع `www/index.html` على [Netlify Drop](https://app.netlify.com/drop) (اسحب الملف).
2. افتح الرابط في **Safari** على الآيفون.
3. زر المشاركة ⬆️ → **"إضافة إلى الشاشة الرئيسية"**.

تطلع أيقونة على شاشتك وتشتغل كأنها تطبيق — بدون أي حساب أو رسوم. 🎉
